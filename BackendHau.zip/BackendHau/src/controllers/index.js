module.exports.studentController = require('./student.controller');
