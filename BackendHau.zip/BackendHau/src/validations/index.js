module.exports.authValidation = require('./auth.validation');
module.exports.zaloValidation = require('./zalo.validation');
