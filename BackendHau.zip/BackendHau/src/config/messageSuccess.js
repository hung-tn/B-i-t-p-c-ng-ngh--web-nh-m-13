const messageSuccess = {
  addCarSuccess: {
    vn: 'Thêm thông tin biển số xe thành công',
    en: 'Add license plate information success',
  },
};
module.exports = messageSuccess;
