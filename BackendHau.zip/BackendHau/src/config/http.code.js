module.exports = {
  HTTP_CODES_STATUS: {
    code_mobile_phone_is_invalid: 100,
    code_otp_must_has_6_characters: 101,
    code_otp_must_contain_numbers: 102,
  },
};
